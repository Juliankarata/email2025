package com.ucp.gestor;

public enum BandejaType {
    ENTRADA,
    ENVIADOS,
    BORRADORES,
    ELIMINADOS,
    FAVORITOS
}
